/* ============================================================
   ResearchFast.Page - lit la page de resultats affichee,
   en extrait les annonces, les classe et montre les meilleures.
   ------------------------------------------------------------
   Tout est construit en DOM (jamais innerHTML) : Facebook et
   Amazon imposent Trusted Types, qui bloquerait innerHTML.
   ============================================================ */

(function () {

/* un exemplaire precedent tourne peut-etre encore */
document.querySelectorAll('#rfp-panel, .rfp-launcher, .rfp-toast').forEach(el => el.remove());

/* ============================================================
   Outils
   ============================================================ */
const txt = el => ((el && el.textContent) || '').replace(/\s+/g, ' ').trim();

/* minuscules sans accents, pour comparer "Écran" et "ecran" */
const norm = s => (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');

/* "1 299,99 $" / "$1,299.99" / "12.50 EUR" -> 1299.99 */
function parsePrice(text) {
  if (!text) return null;
  const t = String(text).replace(/ /g, ' ');
  /* Le premier motif exige un separateur de milliers ("1 299,99", "1,299.99").
     Sans cette exigence, "8822" etait coupe a "882" : \d{1,3} s'arretait a
     trois chiffres et la suite devenait facultative. Le second motif prend
     tout le reste ("8822", "1299.99", "99,2"). */
  const m = t.match(/(\d{1,3}(?:[ .,]\d{3})+(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?)/);
  if (!m) return null;

  let s = m[1];
  const last = Math.max(s.lastIndexOf('.'), s.lastIndexOf(','));
  if (last > -1 && s.length - last - 1 <= 2 && s.length - last - 1 > 0) {
    s = s.slice(0, last).replace(/[ .,]/g, '') + '.' + s.slice(last + 1);
  } else {
    s = s.replace(/[ .,]/g, '');
  }
  const v = parseFloat(s);
  return isFinite(v) && v > 0 ? v : null;
}

function money(v) {
  if (v == null) return '—';
  return v.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' $';
}

const first = (root, selectors) => {
  for (const s of selectors) {
    const el = root.querySelector(s);
    if (el) return el;
  }
  return null;
};

/* Note d'un VENDEUR (eBay) : "pseudo (1 234) 99,2%".
   On la ramene sur 5 etoiles : 90 % -> 0, 95 % -> 2,5, 100 % -> 5.
   En dessous de 95 %, sur eBay, c'est reellement mauvais. */
function sellerOf(card, selectors) {
  const RE = /\(([\d\s.,]+)\)\s*([\d.,]+)\s*%/;

  /* on teste chaque piste, puis le texte entier de la carte : eBay change
     regulierement ses classes et n affiche pas toujours le vendeur. */
  const pistes = [];
  selectors.forEach(s => {
    const el = card.querySelector && card.querySelector(s);
    if (el) pistes.push(txt(el));
  });
  pistes.push(txt(card));

  for (let i = 0; i < pistes.length; i++) {
    const m = pistes[i] && pistes[i].match(RE);
    if (!m) continue;
    const count = parsePrice(m[1]);
    const pct = parsePrice(m[2]);
    /* sous 50 %, c est un rabais mal lu, pas une note de vendeur */
    if (pct == null || pct > 100 || pct < 50) continue;
    return {
      pct,
      count: count || null,
      rating: Math.max(0, Math.min(5, ((pct - 90) / 10) * 5))
    };
  }
  return null;
}

/* Best Buy ecrit les cents en exposant : "$449" + <sup>99</sup>.
   Lu naivement, le texte donne "44999" -> 44 999 $. On separe les deux. */
function bestbuyPrice(el) {
  if (!el) return null;

  const complet = txt(el);
  const sup = el.querySelector && el.querySelector('sup');
  if (!sup) return parsePrice(complet);

  const cents = txt(sup);
  /* on retire l'exposant du texte, ou qu'il se trouve */
  const sansSup = cents ? complet.replace(cents, '') : complet;
  const entier = parsePrice(sansSup);
  if (entier == null) return parsePrice(complet);

  /* si le reste portait deja des decimales ("185,49 $"), l'exposant n'etait
     qu'un habillage : la lecture normale est la bonne */
  if (/[.,]\d{2}/.test(sansSup)) return entier;

  const c = cents.replace(/\D/g, '');
  return c ? entier + Number(c) / 100 : entier;
}

/* Premier montant "123,45 $" trouve dans un texte. Sert de secours quand
   l'element de prix est introuvable : le texte complet d'une carte
   recolle les morceaux, meme si le prix est eclate en plusieurs noeuds. */
function priceFromText(t) {
  const m = String(t || '').replace(/ /g, ' ')
    .match(/(\d[\d\s.,]*[.,]\d{2})\s*\$|\$\s*(\d[\d\s.,]*)/);
  return m ? parsePrice(m[1] || m[2]) : null;
}

/* Textes qui ne sont pas des noms de produit : pastilles de coloris et
   liens de notation, qui pointent pourtant vers la meme fiche. */
const PARASITE = /^(couleur|colour|color|capacit|taille|size|modele|mod[eè]le)\s*:|étoiles?\s+sur\s+5|stars?\s+out\s+of\s+5|^\d+\s*(commentaire|avis|review)/i;

/* eBay colle des mentions d accessibilite a la fin des titres */
function cleanTitle(t) {
  return String(t || '')
    .replace(/opens? in a new (window|tab).*$/i, '')
    .replace(/ouvre dans (un|une) nouve.*$/i, '')
    .replace(/^(new listing|nouvelle annonce)\s*/i, '')
    .trim();
}

/* ============================================================
   Lecteurs par site
   ============================================================ */
const SITES = [

  /* ---------------- Amazon ---------------- */
  {
    id: 'amazon', name: 'Amazon', delay: 1200,
    test: h => /(^|\.)amazon\./.test(h),
    parse() {
      const cards = document.querySelectorAll(
        'div[data-component-type="s-search-result"], div.s-result-item[data-asin]:not([data-asin=""])');
      const out = [];

      cards.forEach(card => {
        const titleEl = first(card, ['h2 a span', 'h2 span', '[data-cy="title-recipe"] span', 'h2']);
        const title = txt(titleEl);
        if (!title) return;

        const priceEl = first(card, ['.a-price > .a-offscreen', '.a-price .a-offscreen', '.a-color-price']);
        const price = parsePrice(txt(priceEl));

        const link = first(card, ['h2 a', 'a.a-link-normal.s-no-outline', 'a.a-link-normal']);
        const img = card.querySelector('img.s-image');

        const rateEl = first(card, ['i.a-icon-star-small span', 'span.a-icon-alt', 'i.a-icon-star span']);
        const rating = rateEl ? parsePrice(txt(rateEl)) : null;

        const revEl = first(card, ['span.a-size-base.s-underline-text', 'a[href*="customerReviews"] span']);
        const reviews = revEl ? parsePrice(txt(revEl)) : null;

        const sponsored = /sponsoris|sponsored|gesponsert/i.test(txt(card).slice(0, 200));

        out.push({
          title, price,
          url: link ? link.href : location.href,
          img: img ? img.src : '',
          rating: rating && rating <= 5 ? rating : null,
          reviews: reviews || null,
          ratingKind: 'product',        /* Amazon : note de la fiche produit */
          note: sponsored ? 'sponsorisé' : ''
        });
      });
      return out;
    }
  },

  /* ---------------- eBay ---------------- */
  {
    id: 'ebay', name: 'eBay', delay: 900,
    test: h => /(^|\.)ebay\./.test(h),
    parse() {
      const out = [];
      document.querySelectorAll('li.s-item, li.s-card, .srp-results li[data-viewport]').forEach(card => {
        const title = cleanTitle(txt(first(card, ['.s-item__title', '.s-card__title', 'h3'])));
        if (!title || /^shop on ebay$/i.test(title)) return;

        const price = parsePrice(txt(first(card, ['.s-item__price', '.s-card__price'])));
        const link = first(card, ['a.s-item__link', 'a.s-card__link', 'a[href*="/itm/"]']);
        const img = first(card, ['.s-item__image img', 'img']);
        const ship = txt(first(card, ['.s-item__shipping', '.s-item__logisticsCost']));

        /* Sur eBay ce qui compte c'est le VENDEUR, pas la fiche produit :
           "pseudo (1 234) 99,2%" -> 1234 ventes, 99,2 % d'avis positifs. */
        const seller = sellerOf(card, ['.s-item__seller-info-text', '.s-item__seller-info',
                                       '.s-card__seller-info', '.s-card__attribute-row']);

        out.push({
          title, price,
          url: link ? link.href : location.href,
          img: img ? (img.src || img.dataset.src || '') : '',
          rating: seller ? seller.rating : null,
          reviews: seller ? seller.count : null,
          sellerPct: seller ? seller.pct : null,
          ratingKind: seller ? 'seller' : 'none',
          note: /gratuit|free/i.test(ship) ? 'livraison gratuite' : ''
        });
      });
      return out;
    }
  },

  /* ---------------- Best Buy ---------------- */
  {
    id: 'bestbuy', name: 'Best Buy', delay: 1800,
    test: h => /(^|\.)bestbuy\./.test(h),

    /* Best Buy change son adresse de recherche sans prevenir et bloque toute
       verification automatique. Plutot que de deviner un chemin qui finit en
       404, on ouvre son accueil et on tape dans SON champ de recherche : c'est
       le site lui-meme qui fabrique la bonne adresse. */
    searchBox: ['input[type="search"]', '#globalSearchInput', 'input[name="search"]',
                'input[placeholder*="echerch"]', 'input[aria-label*="echerch"]',
                'input[aria-label*="Search"]', 'header input[type="text"]'],
    isResults: () => location.search.length > 1 ||
                     /\/(search|collection|category)/i.test(location.pathname),
    parse() {
      const out = [];
      const seen = new Set();

      /* Chaque vignette pointe vers la fiche produit : on part des liens, plus
         stables que les classes generees par leur outil de compilation.
         ATTENTION : le chemin est traduit, comme pour la recherche.
         En francais c'est /produit/, en anglais /product/. */
      document.querySelectorAll('a[href*="/product/"], a[href*="/produit/"]').forEach(link => {
        const url = link.href;
        if (!url) return;

        /* Une fiche est referencee par plusieurs liens : l'image, le titre, la
           note, et une pastille par coloris. On dedoublonne sur l'identifiant
           numerique de la fiche plutot que sur l'adresse complete, sinon le
           meme telephone revient six fois sous des titres comme "Couleur: Lilas". */
        const id = (url.match(/(\d{6,})/) || [])[1] || url;
        if (seen.has(id)) return;

        /* On remonte jusqu'au premier ancetre qui contient un montant : c'est
           la vignette. Se fier a la longueur du texte ne marchait pas — le
           lien du titre est deja long, donc on ne montait jamais jusqu'au prix.
           Chercher une classe precise ne marche pas non plus : Best Buy les
           renomme a chaque deploiement. */
        let card = link, depth = 0;
        while (card.parentElement && depth < 6 && txt(card).indexOf('$') === -1) {
          card = card.parentElement;
          depth++;
        }

        /* Le vrai titre est celui du lien produit. Les autres liens de la
           vignette portent un texte parasite : on prend alors celui de la carte. */
        let title = cleanTitle(txt(link));
        if (!title || PARASITE.test(title) || title.length < 8) {
          title = cleanTitle(link.getAttribute('aria-label') ||
                             txt(first(card, ['[data-automation*="Name"]', 'h3', 'h4'])) || '');
        }
        if (!title || title.length < 5 || PARASITE.test(title)) return;
        seen.add(id);

        /* d'abord l'element de prix, puis a defaut le texte entier de la
           carte : le montant y est reconstitue meme s'il est decoupe en
           plusieurs noeuds ("185," + "49" + " $") */
        let price = bestbuyPrice(
          first(card, ['[data-automation="product-price"] span', '[data-automation="product-price"]',
                       '[data-automation*="price"]', '[class*="price"] span', '[class*="price"]']));
        if (price == null) price = priceFromText(txt(card));

        /* la note vient de la fiche produit, comme chez Amazon */
        let rating = null;
        const aria = card.querySelector('[aria-label*="sur 5"], [aria-label*="out of 5"]');
        if (aria) {
          const m = (aria.getAttribute('aria-label') || '').match(/(\d+[.,]\d+|\d+)\s*(?:sur|out of)\s*5/i);
          if (m) rating = parsePrice(m[1]);
        }
        const revEl = first(card, ['[data-automation="rating-count"]', '[class*="ratingCount"]']);
        let reviews = revEl ? parsePrice(txt(revEl)) : null;
        if (reviews == null) {
          /* a defaut, le nombre entre parentheses : "(77)" */
          const m = txt(card).match(/\((\d[\d\s.,]*)\)/);
          if (m) reviews = parsePrice(m[1]);
        }

        const img = card.querySelector('img');

        out.push({
          title, price, url,
          img: img ? (img.src || img.getAttribute('data-src') || '') : '',
          rating: rating != null && rating <= 5 ? rating : null,
          reviews: reviews || null,
          ratingKind: 'product',
          note: ''
        });
      });
      return out;
    }
  },

  /* ---------------- Newegg ---------------- */
  {
    id: 'newegg', name: 'Newegg', delay: 1500,
    test: h => /(^|\.)newegg\./.test(h),
    parse() {
      const out = [];
      const seen = new Set();

      /* une vignette = .item-cell, mais Newegg renomme ses classes assez
         souvent : on part plutot des liens de fiche produit (toujours
         "/p/" dans l'adresse), comme pour Best Buy. */
      document.querySelectorAll(
        '.item-cell, a.item-title, a[href*="/p/N82E"], a[href*="/p/"]'
      ).forEach(node => {
        const card = node.classList && node.classList.contains('item-cell')
          ? node : (node.closest ? node.closest('.item-cell') : null);
        if (!card) return;

        const link = first(card, ['a.item-title', 'a.item-img', 'a[href*="/p/"]']);
        const url = link ? link.href : '';
        if (!url) return;

        /* identifiant de fiche plutot que l'adresse complete : certains liens
           de la meme vignette (image, titre, avis) ne partagent pas tout a
           fait la meme URL (ancre #tab-reviews, parametres de tri...) */
        const id = (url.match(/\/p\/([A-Za-z0-9]+)/) || [])[1] || url;
        if (seen.has(id)) return;

        const title = cleanTitle(txt(first(card, ['a.item-title', '[class*="item-title"]'])));
        if (!title || title.length < 5) return;
        seen.add(id);

        const price = parsePrice(txt(first(card,
          ['li.price-current', '.price-current', '[class*="price-current"]'])));

        const img = card.querySelector('img');

        /* "i.rating.rating-45" -> 4,5 etoiles ; "rating-5" -> 5 etoiles.
           Plusieurs elements de la vignette contiennent "rating-" dans leur
           classe (le compteur d'avis par ex.) sans porter le chiffre : on
           cherche celui qui a vraiment un nombre apres le tiret. */
        let rating = null;
        const etoiles = card.querySelectorAll('[class*="rating-"]');
        for (let i = 0; i < etoiles.length; i++) {
          const m = (etoiles[i].className || '').match(/\brating-(\d{1,2})\b/);
          if (!m) continue;
          const n = Number(m[1]);
          rating = n > 5 ? n / 10 : n;
          break;
        }

        const revEl = first(card, ['.item-rating-num', '[class*="rating-num"]']);
        const reviews = revEl ? parsePrice(txt(revEl).replace(/[()]/g, '')) : null;

        const sponsored = /sponsoris|sponsored/i.test(txt(card).slice(0, 220));

        out.push({
          title, price, url,
          img: img ? (img.src || img.getAttribute('data-src') || '') : '',
          rating: rating != null && rating <= 5 ? rating : null,
          reviews: reviews || null,
          ratingKind: 'product',
          note: sponsored ? 'sponsorisé' : ''
        });
      });
      return out;
    }
  },

  /* ---------------- Facebook Marketplace ---------------- */
  {
    id: 'facebook', name: 'Marketplace', delay: 2600,
    test: h => /(^|\.)facebook\./.test(h),
    parse() {
      const out = [];
      const seen = new Set();

      document.querySelectorAll('a[href*="/marketplace/item/"]').forEach(link => {
        const id = (link.getAttribute('href').match(/item\/(\d+)/) || [])[1];
        if (!id || seen.has(id)) return;
        seen.add(id);

        /* Marketplace n'a pas de classes stables : on lit les lignes de texte
           de la carte et on devine le prix et le titre. */
        const lines = [];
        link.querySelectorAll('span, div').forEach(n => {
          if (n.children.length === 0) {
            const t = txt(n);
            if (t && !lines.includes(t)) lines.push(t);
          }
        });
        if (!lines.length) return;

        const priceLine = lines.find(l => /^\s*(gratuit|free|[\d\s.,]*\s*\$|\$\s*[\d\s.,]+)/i.test(l));
        const price = /gratuit|free/i.test(priceLine || '') ? 0 : parsePrice(priceLine);

        const title = lines
          .filter(l => l !== priceLine && l.length > 3)
          .sort((a, b) => b.length - a.length)[0] || lines[0];

        /* "80 $CA" est un ancien prix, pas un lieu : on ecarte tout ce qui
           ressemble a un montant avant de chercher la ville. */
        const looksPrice = l => /[$€£]/.test(l)
                             || /^\s*[\d\s.,]+\s*$/.test(l)
                             || /^(gratuit|free)$/i.test(l);
        const place = lines.find(l => l !== title && l !== priceLine && !looksPrice(l) && l.length < 40) || '';
        const img = link.querySelector('img');

        out.push({
          title, price,
          url: link.href,
          img: img ? img.src : '',
          /* Marketplace n'affiche pas la note du vendeur dans les resultats :
             elle n'existe que sur la fiche de l'annonce. */
          rating: null, reviews: null, ratingKind: 'none',
          note: place
        });
      });
      return out;
    }
  },

  /* ---------------- n'importe quel autre site ---------------- */
  {
    id: 'generic', name: 'Cette page', delay: 1400, generic: true,
    test: () => true,
    parse() {
      const out = [];
      const seen = new Set();
      const RE = /(?:\$|€|£|CAD|USD)\s*\d|\d[\d\s.,]*\s*(?:\$|€|£)/;

      /* on cherche les petits blocs de texte qui ressemblent a un prix,
         puis on remonte jusqu'a la carte produit qui les contient.
         Plafond de noeuds visites : certaines pages (fils infinis, grosses
         grilles) en comptent des dizaines de milliers, et parcourir tout
         le DOM a chaque rescan les faisait raguer pour rien. 120 annonces
         suffisent largement a l'affichage, pas la peine de lire le reste. */
      const noeuds = document.querySelectorAll('span, div, p, strong, b');
      const plafond = Math.min(noeuds.length, 6000);
      for (let i = 0; i < plafond && out.length < 120; i++) {
        const node = noeuds[i];
        /* On accepte les petits conteneurs, pas seulement les feuilles :
           un prix est souvent decoupe ("185," + <sup>49</sup> + " $"), et
           n'apparait entier que sur l'element qui les regroupe. */
        if (node.children.length > 3) continue;
        const t = txt(node);
        if (t.length > 30 || !RE.test(t)) continue;

        const price = parsePrice(t);
        if (!price) continue;

        let card = node, link = null, depth = 0;
        while (card && depth < 7) {
          link = card.querySelector && card.querySelector('a[href]');
          if (link && txt(card).length > t.length + 10) break;
          card = card.parentElement;
          depth++;
        }
        if (!card || !link) continue;

        const url = link.href;
        if (!url || seen.has(url)) continue;
        seen.add(url);

        const title = (txt(link) || txt(card)).replace(t, '').trim().slice(0, 140);
        if (title.length < 6) continue;

        const img = card.querySelector('img');
        out.push({
          title, price, url,
          img: img ? img.src : '',
          rating: null, reviews: null, ratingKind: 'none', note: ''
        });
      }
      return out;
    }
  }
];

const SITE = SITES.find(s => s.test(location.hostname)) || SITES[SITES.length - 1];

/* Le classement vit dans rank.js, partage avec le popup. */

/* ============================================================
   Le panneau
   ============================================================ */
/* paliers du curseur : definis une seule fois dans rank.js */
const STOPS = RFPRank.STOPS, LAST = RFPRank.LAST, stopIndex = RFPRank.stopIndex;

let panel = null, panelMode = null;
let secoursTente = false;   /* une seule tentative de rattrapage par page */
let reprises = 0;           /* relectures quand la page se remplit encore */
let state = { raw: [], all: [], query: '', sort: 'score', budget: null, filters: {}, mode: null };

/* Reclasse tout : la ponderation depend du budget, donc bouger le
   curseur change l'ordre — mais sans jamais relire la page. */
function rescore() {
  const r = RFPRank.rank(state.raw, state.query, state.filters, state.budget);
  state.all = r.items;
  state.mode = r.mode;
  state.cheapest = r.cheapest;
}

/* les annonces qui rentrent dans le budget courant */
function visible() {
  const b = state.budget;
  return state.all.filter(it => b == null || (it.price != null && it.price <= b));
}

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}

function buildPanel() {
  if (panel) panel.remove();

  panel = el('div');
  panel.id = 'rfp-panel';

  /* --- en-tete --- */
  const head = el('div', 'rfp-head');
  const brand = el('div', 'rfp-brand');
  brand.append(el('span', 'rfp-logo', '🔎'), el('span', null, 'ResearchFast'));
  const close = el('button', 'rfp-close', '×');
  close.title = 'Fermer';
  close.addEventListener('click', () => { panel.remove(); panel = null; });
  head.append(brand, close);

  const q = el('div', 'rfp-query', state.query ? '« ' + state.query + ' »' : 'Toutes les annonces');

  /* --- curseur de budget --- */
  const bud = el('div', 'rfp-budget');

  /* --- prix minimum --- */
  const mTop = el('div', 'rfp-budget-top');
  const mVal = el('span', 'rfp-budget-val');
  mTop.append(el('span', 'rfp-budget-lbl', 'Prix minimum'), mVal);

  const minRange = document.createElement('input');
  minRange.type = 'range';
  minRange.className = 'rfp-range';
  RFPRank.setupRange(minRange, RFPRank.MIN_STOPS, state.filters.minPrice);

  /* --- budget maximum --- */
  const bTop = el('div', 'rfp-budget-top rfp-second');
  const bVal = el('span', 'rfp-budget-val');
  bTop.append(el('span', 'rfp-budget-lbl', 'Budget max'), bVal);

  const range = document.createElement('input');
  range.type = 'range';
  range.className = 'rfp-range';
  RFPRank.setupSlider(range, state.budget);

  /* Les deux bornes ne peuvent pas se croiser : celle qu'on ne bouge pas cede.
     Le minimum filtre le classement, donc on reclasse a chaque changement. */
  const bouge = qui => {
    RFPRank.clampBounds(state.filters, qui);
    state.budget = state.filters.maxPrice;
    RFPRank.setupRange(minRange, RFPRank.MIN_STOPS, state.filters.minPrice);
    RFPRank.setupSlider(range, state.budget);
    rescore();
    paintBudget();
    renderList();
    saveBudget();
  };

  minRange.addEventListener('input', () => {
    state.filters.minPrice = RFPRank.MIN_STOPS[Number(minRange.value)];
    bouge('min');
  });

  range.addEventListener('input', () => {
    state.filters.maxPrice = STOPS[Number(range.value)];
    bouge('max');
  });

  const mode = el('div', 'rfp-mode');
  bud.append(mTop, minRange, bTop, range, mode);
  panelMode = mode;

  /* --- barre de tri --- */
  const bar = el('div', 'rfp-bar');
  const count = el('span', 'rfp-count');
  const sort = el('select', 'rfp-sort');
  [['score', 'Meilleure offre'], ['price', 'Prix croissant'],
   ['rating', 'Mieux notés'], ['title', 'Alphabétique']].forEach(o => {
    const opt = el('option', null, o[1]);
    opt.value = o[0];
    sort.appendChild(opt);
  });
  sort.value = state.sort;
  sort.addEventListener('change', () => { state.sort = sort.value; renderList(); });
  bar.append(count, sort);

  const list = el('div', 'rfp-list');

  /* --- pied --- */
  const foot = el('div', 'rfp-foot');
  const again = el('button', 'rfp-btn', '↻ Rescanner');
  again.addEventListener('click', () => run(true));
  const more = el('button', 'rfp-btn', '⬇ Charger plus');
  more.title = 'Fait défiler la page pour charger d\'autres annonces, puis rescanne';
  more.addEventListener('click', loadMore);
  foot.append(again, more);

  panel.append(head, q, bud, bar, list, foot);
  document.body.appendChild(panel);

  panel._count = count;
  panel._list = list;
  panel._range = range;
  panel._bval = bVal;
  panel._minRange = minRange;
  panel._mval = mVal;
  paintBudget();
}

function paintBudget() {
  if (!panel) return;
  const b = state.budget;
  panel._bval.textContent = b == null ? 'sans limite' : b.toLocaleString('fr-CA') + ' $';
  panel._bval.classList.toggle('is-open', b == null);

  const m = state.filters.minPrice;
  panel._mval.textContent = m == null ? 'aucun' : m.toLocaleString('fr-CA') + ' $';
  panel._mval.classList.toggle('is-open', m == null);

  RFPRank.paintRange(panel._minRange, RFPRank.MIN_STOPS);
  panel._range.style.setProperty('--fill', Math.round((panel._range.value / LAST) * 100) + '%');
  if (panelMode && state.mode) panelMode.textContent = state.mode.label;
}

/* le budget suit dans le popup, et inversement */
function saveBudget() {
  clearTimeout(saveBudget.t);
  saveBudget.t = setTimeout(() => {
    chrome.storage.local.get({ filters: {} }, r => {
      const f = r.filters || {};
      f.maxPrice = state.budget;
      f.minPrice = state.filters.minPrice;
      chrome.storage.local.set({ filters: f });
    });
  }, 250);
}

function renderList() {
  const list = panel._list;
  list.textContent = '';

  const items = visible();
  if (state.sort === 'price') items.sort((a, b) => (a.price == null) - (b.price == null) || a.price - b.price);
  if (state.sort === 'rating') items.sort((a, b) => (b.rating || 0) - (a.rating || 0));
  if (state.sort === 'title') items.sort((a, b) => a.title.localeCompare(b.title));

  panel._count.textContent = items.length + (items.length > 1 ? ' offres' : ' offre')
    + (state.budget != null && items.length < state.all.length
        ? ' sur ' + state.all.length : '');

  if (!items.length) {
    const empty = el('div', 'rfp-empty');
    const cheap = state.all.filter(it => it.price != null).sort((a, b) => a.price - b.price)[0];

    /* Trois raisons possibles a une liste vide, et il faut dire laquelle :
       la page n'a pas ete comprise, la recherche a tout ecarte, ou tout
       depasse le budget. Un "rien trouve" indistinct n'aide personne. */
    if (state.all.length && state.budget != null) {
      empty.append(
        el('div', 'rfp-empty-icon', '💸'),
        el('div', null, 'Rien sous ' + state.budget.toLocaleString('fr-CA') + ' $.'),
        el('div', 'rfp-empty-sub', cheap
          ? 'Le moins cher ici est à ' + Math.round(cheap.price).toLocaleString('fr-CA') + ' $.'
          : 'Remonte le curseur.'));

    } else if (state.raw.length) {
      /* des annonces ont bien ete lues, mais aucune n'a passe les filtres */
      empty.append(
        el('div', 'rfp-empty-icon', '🔍'),
        el('div', null, state.raw.length + ' annonces lues, aucune ne correspond.'),
        el('div', 'rfp-empty-sub', state.query
          ? 'Aucune ne contient « ' + state.query + ' ». Essaie moins de mots, ou vérifie les filtres.'
          : 'Vérifie le prix minimum, la note minimale et les mots exclus.'));

    } else {
      empty.append(
        el('div', 'rfp-empty-icon', '🤷'),
        el('div', null, 'Page non reconnue.'),
        el('div', 'rfp-empty-sub',
           'Aucune annonce lisible ici. Lance une recherche sur le site, puis rescanne.'));
    }
    list.appendChild(empty);
    return;
  }

  items.slice(0, 60).forEach((it, i) => {
    const row = el('a', 'rfp-item' + (i === 0 && state.sort === 'score' ? ' is-best' : ''));
    row.href = it.url;
    row.target = '_blank';
    row.rel = 'noopener';

    if (it.img) {
      const im = el('img', 'rfp-img');
      im.src = it.img;
      im.loading = 'lazy';
      row.appendChild(im);
    } else {
      row.appendChild(el('div', 'rfp-img rfp-noimg', '📦'));
    }

    const mid = el('div', 'rfp-mid');
    mid.appendChild(el('div', 'rfp-title', it.title));

    const meta = el('div', 'rfp-meta');
    const lab = RFPRank.ratingLabel(it);
    if (lab) {
      meta.appendChild(el('span', 'rfp-star is-' + lab.kind, lab.text));
      if (lab.sub) meta.appendChild(el('span', null, lab.sub));
    }
    if (it.note) meta.appendChild(el('span', 'rfp-note', it.note));
    meta.appendChild(el('span', 'rfp-badge', SITE.name));
    mid.appendChild(meta);

    const right = el('div', 'rfp-right');
    right.appendChild(el('div', 'rfp-price', it.price === 0 ? 'Gratuit' : money(it.price)));
    right.appendChild(el('div', 'rfp-score', it.score + ' pts'));

    row.append(mid, right);
    if (i === 0 && state.sort === 'score') row.appendChild(el('div', 'rfp-ribbon', 'MEILLEURE OFFRE'));
    list.appendChild(row);
  });
}

function toast(message) {
  document.querySelectorAll('.rfp-toast').forEach(t => t.remove());
  const t = el('div', 'rfp-toast', message);
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2600);
}

/* fait defiler pour declencher le chargement paresseux, puis rescanne */
function loadMore() {
  const y = window.scrollY;
  window.scrollTo(0, document.body.scrollHeight);
  toast('Chargement des annonces suivantes...');
  setTimeout(() => {
    window.scrollTo(0, y);
    run(true);
  }, 1800);
}

/* ============================================================
   Scan
   ============================================================ */
function run(silent) {
  chrome.storage.local.get({ query: '', filters: {}, results: {}, searchStamp: 0 }, cfg => {
    let raw = [];
    try {
      raw = SITE.parse() || [];
    } catch (e) {
      toast('Lecture impossible sur cette page.');
      return;
    }

    /* le lecteur generique sert de secours si le lecteur du site ne donne rien */
    if (!raw.length && !SITE.generic) {
      try { raw = SITES[SITES.length - 1].parse() || []; } catch (e) { raw = []; }
    }


    const filters = cfg.filters || {};
    state.query = cfg.query || '';
    state.filters = filters;
    state.budget = filters.maxPrice != null ? filters.maxPrice : null;
    raw.forEach(it => { it.siteId = SITE.id; });
    state.raw = raw;
    rescore();

    /* On enregistre les annonces BRUTES (state.raw), pas state.all. state.all
       est deja passe par rank() : mots exclus, note minimale, sponsorises
       masques. Si on stockait ca, remonter la note minimale ou retirer un mot
       exclu plus tard dans le popup ne ferait rien reapparaitre - ces
       annonces auraient deja disparu du stockage pour de bon. Le popup et
       la page de comparaison appliquent deja rank() eux-memes sur les
       resultats fusionnes : c'est a eux de filtrer, pas au scan de decider
       une fois pour toutes. Le budget, lui, n'a jamais pose ce probleme :
       il ne filtre qu'a l'affichage. */
    const results = cfg.results || {};
    results[SITE.id] = {
      site: SITE.name,
      url: location.href,
      stamp: cfg.searchStamp,   /* quelle recherche a produit ces resultats */
      when: Date.now(),
      items: state.raw.slice(0, 80)
    };
    /* On enregistre TOUJOURS, meme une liste vide : sinon la colonne de la
       page de comparaison reste indefiniment sur "scan en cours". */
    chrome.storage.local.set({ results });

    buildPanel();
    renderList();

    /* Beaucoup de boutiques affichent leurs vignettes en JavaScript, apres le
       chargement. Si la recolte est maigre, on relit la page un peu plus tard :
       deux reprises suffisent, et chacune remplace la precedente. */
    if (state.raw.length < 5 && reprises < 2) {
      reprises++;
      setTimeout(() => run(true), 3500 * reprises);
    }

    /* Rien trouve et on n'est pas sur une page de resultats (404, accueil,
       adresse changee de leur cote) : on se rattrape en tapant dans leur
       propre champ de recherche. Une seule fois par page. */
    if (!state.all.length && SITE.searchBox && SITE.isResults && !SITE.isResults()
        && !secoursTente && cfg.searchStamp && cfg.query) {
      secoursTente = true;
      typeSearch(cfg.query);
      return;
    }

    if (!silent && !state.all.length) toast('Aucune annonce reconnue ici.');
  });
}

/* ============================================================
   Recherche tapee dans le champ du site
   ------------------------------------------------------------
   Pour les boutiques dont on ne connait pas l'adresse de recherche,
   on remplit leur propre champ et on valide. Le site produit alors
   l'adresse correcte, et le scan se declenche sur ses resultats.
   ============================================================ */
function typeSearch(q) {
  const input = first(document, SITE.searchBox);
  if (!input) return false;

  /* les champs pilotes par React ignorent une simple affectation :
     il faut passer par le setter natif puis annoncer l'evenement */
  try {
    const natif = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
    if (natif && natif.set) natif.set.call(input, q);
    else input.value = q;
  } catch (e) {
    input.value = q;
  }
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  input.focus();

  toast('Recherche de « ' + q + ' » sur ' + SITE.name + '...');

  setTimeout(() => {
    if (input.form && input.form.requestSubmit) {
      input.form.requestSubmit();
    } else {
      ['keydown', 'keypress', 'keyup'].forEach(t => {
        input.dispatchEvent(new KeyboardEvent(t, {
          key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true
        }));
      });
    }
  }, 300);

  /* ces sites naviguent souvent sans recharger la page : on guette
     le changement d'adresse pour lancer le scan au bon moment */
  let derniere = location.href;
  const veille = setInterval(() => {
    if (location.href === derniere) return;
    derniere = location.href;
    clearInterval(veille);
    setTimeout(() => run(true), 1600);
  }, 400);
  setTimeout(() => clearInterval(veille), 25000);

  /* Garantie : si la saisie ne mene nulle part, on scanne quand meme la page
     au bout de 12 s. Sans ca, la colonne du comparateur resterait
     indefiniment sur "scan en cours". */
  setTimeout(() => {
    if (location.href === derniere) run(true);
  }, 12000);

  return true;
}

/* bouton flottant discret quand on n'a rien demande */
function launcher() {
  const b = el('button', 'rfp-launcher', '🔎');
  b.title = 'ResearchFast : scanner cette page';
  b.addEventListener('click', () => { b.remove(); run(false); });
  document.body.appendChild(b);
}

/* ============================================================
   Demarrage
   ============================================================ */
/* Chaque onglet decide seul s'il doit se scanner : on compare le marqueur
   de la recherche en cours a celui deja enregistre pour CE site. Avant, le
   premier site termine effacait un drapeau commun et les onglets plus lents
   (Amazon surtout) ne se scannaient jamais. */
chrome.storage.local.get({ query: '', searchStamp: 0, results: {} }, cfg => {
  const mine = (cfg.results || {})[SITE.id];
  const aFaire = cfg.searchStamp && cfg.query &&
                 (!mine || mine.stamp !== cfg.searchStamp || mine.url !== location.href);

  if (!aFaire) { launcher(); return; }

  /* site sans adresse de recherche connue, et on n'est pas encore sur ses
     resultats : on tape la recherche dans son propre champ */
  if (SITE.searchBox && SITE.isResults && !SITE.isResults()) {
    setTimeout(() => {
      if (!typeSearch(cfg.query)) {
        toast('Tape ta recherche ici, le scan se fera tout seul.');
        launcher();
      }
    }, SITE.delay);
    return;
  }

  setTimeout(() => run(true), SITE.delay);
});

/* si le budget est bouge depuis le popup, le panneau suit */
chrome.storage.onChanged.addListener(ch => {
  if (!ch.filters || !panel) return;

  const f = ch.filters.newValue || {};
  const max = f.maxPrice != null ? f.maxPrice : null;
  const min = f.minPrice != null ? f.minPrice : null;

  /* rien de neuf sur les deux bornes : inutile de tout refaire */
  if (max === state.budget && min === state.filters.minPrice) return;

  state.filters = f;
  state.budget = max;
  rescore();
  RFPRank.setupRange(panel._minRange, RFPRank.MIN_STOPS, min);
  RFPRank.setupSlider(panel._range, max);
  paintBudget();
  renderList();
});

chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (msg.action === 'scan') {
    run(false);
    respond({ ok: true, handled: true, site: SITE.name });
  } else if (msg.action === 'ping') {
    respond({ ok: true, handled: true, site: SITE.name });
  } else {
    respond({ ok: false, reason: 'unknown' });
  }
  return true;
});

})();
