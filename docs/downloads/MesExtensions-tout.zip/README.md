<div align="center">

# Mes extensions Chrome

**GameOpen** · **PageCustomer** · **PetPage** · **ResearchFast.Page** · **SnapCoach** · **KeySound** · **FocusBlock**

Sept extensions faites maison, gratuites, sans publicité et sans collecte de données.

### 👉 [**Page de téléchargement**](https://scgaming887-svg.github.io/mes-extensions-chrome/) 👈

*Elles y sont toutes, avec un bouton par extension et un pack complet.*

</div>

---

## Les sept extensions

<table>
<tr>
<td width="80"><img src="GameOpen/icons/icon128.png" width="64"></td>
<td>

### GameOpen · v1.1.0
[⬇️ Télécharger](https://scgaming887-svg.github.io/mes-extensions-chrome/downloads/GameOpen.zip)

Lance tes applications de bureau depuis le navigateur, et joue en attendant.

- 9 raccourcis prêts : Roblox, Discord, Steam, Spotify, Epic, Minecraft, Twitch, VS Code, YouTube
- Clic gauche : ouvre l'application installée · Clic droit : ouvre la version web
- Ajoute tes propres raccourcis (nom, emoji, protocole, site)
- **Six mini-jeux** intégrés, records sauvegardés : Snake, Casse-brique, Flappy, 2048, Paires, Simon

</td>
</tr>
<tr>
<td><img src="PageCustomer/icons/icon128.png" width="64"></td>
<td>

### PageCustomer · v1.0.0
[⬇️ Télécharger](https://scgaming887-svg.github.io/mes-extensions-chrome/downloads/PageCustomer.zip)

Change l'apparence de n'importe quel site.

- 6 thèmes en un clic : Nuit, Sépia, Néon, Lecture, Pastel
- Réglages express : mode sombre, gros texte, colonne de lecture, sans images, sans animations
- Couleurs, police, zoom, interligne, largeur de lecture, coins arrondis
- Filtres luminosité / contraste / saturation, et une zone de CSS personnalisé
- Réglages **par site** ou **pour tous les sites**

</td>
</tr>
<tr>
<td><img src="PetPage/icons/icon128.png" width="64"></td>
<td>

### PetPage · v1.2.1
[⬇️ Télécharger](https://scgaming887-svg.github.io/mes-extensions-chrome/downloads/PetPage.zip)

Un compagnon animé qui vit en bas de tes pages.

- 18 animaux au choix, taille, vitesse et nom réglables
- Il marche, s'ennuie, s'endort, saute tout seul et te suit à la souris
- Nourriture adaptée à l'espèce : poisson pour le chat, os pour le chien, carotte pour le lapin…
- Physique réelle : attrape-le, lance-le, il retombe et s'écrase au sol
- **Il a faim, et ça se voit** : la faim court sur l'horloge réelle et survit à la fermeture du navigateur
  - petit creux → il te le dit
  - affamé → il **s'allonge** sur le flanc, les couleurs pâlissent
  - à bout → il **se fâche**, tremble, refuse les câlins tant qu'il n'a pas mangé
  - jauge d'humeur dans le popup, et vitesse de la faim réglable (8 h / 3 h / 25 min)
  - **l'exercice creuse l'appétit** : chaque saut que *tu* déclenches avance la jauge d'environ 1 % — ses sauts spontanés, eux, ne comptent pas
- **Il va se coucher** : un lit apparaît, il marche jusqu'à lui, s'y endort avec des 💤 — un clic le réveille
- **Trois mini-jeux** lancés depuis le popup, joués directement sur la page :
  - 🍬 *Attrape les friandises* — bouge la souris, rattrape tout avant le sol (3 vies)
  - 🌵 *Saute les obstacles* — course sans fin, Espace ou clic pour sauter
  - 🏁 *La grande course* — clique le plus vite possible pour battre le rival
- Désactivable site par site

</td>
</tr>
<tr>
<td><img src="ResearchFast.Page/icons/icon128.png" width="64"></td>
<td>

### ResearchFast.Page · v1.7.0
[⬇️ Télécharger](https://scgaming887-svg.github.io/mes-extensions-chrome/downloads/ResearchFast.Page.zip)

Trouve la meilleure offre pour ce que tu cherches.

- Tape ton article : l'extension ouvre la recherche sur **Amazon, eBay, Best Buy, Newegg et Marketplace** d'un coup
- **Page de comparaison** : une colonne par site, remplie en direct pendant que les onglets se scannent en arrière-plan — plus besoin de les visiter un par un
- **Top 3 dans des onglets** : ouvre les trois meilleures offres toutes boutiques confondues en un clic, sans repasser par chaque colonne
- **Export CSV** : télécharge les offres affichées (titre, prix, note, score, lien) pour les comparer ailleurs ou les garder
- **Barre de recherche intégrée** à la page de comparaison : relance une recherche sans repasser par le popup
- Elle lit chaque page de résultats et en extrait titre, prix, note et fiabilité
- **Deux curseurs de prix** — un minimum et un budget maximum, jusqu'à 100 000 $ — avec refiltrage instantané sans rescanner. Ils ne peuvent pas se croiser : celui qu'on ne bouge pas cède
- **Le classement s'adapte à ton budget** (voir plus bas)
- **La note veut dire ce qu'elle dit** : Amazon, Best Buy et Newegg notent le produit, eBay note le **vendeur**, Marketplace ne publie rien
- Écarte les accessoires : chercher « casque bluetooth » ne remonte pas les étuis pour casque — mais si la boutique nomme ses produits autrement (« Galaxy A17 » pour un téléphone), rien n'est écarté : le site a déjà fait le tri
- **Relit la page toute seule** si elle se remplit après coup, comme le font les boutiques qui affichent leurs vignettes en JavaScript
- Filtres : prix minimum, note minimale, mots à exclure, masquer les sponsorisés — **remonter un filtre fait réapparaître les annonces qu'il cachait, sans avoir à rescanner**
- Mode générique de secours sur les autres boutiques, avec un plafond de lecture pour rester fluide même sur une très grosse page
- Quand une liste est vide, le panneau **dit pourquoi** : page non reconnue, aucune annonce ne correspond à la recherche, ou tout dépasse le budget
- Sur Best Buy, la recherche est **tapée dans le champ du site** : son adresse de recherche change sans prévenir, donc on la laisse la fabriquer elle-même
- Marketplace est provisoirement capricieux côté scan (Facebook change souvent sa page) — en attendant, privilégie les quatre autres boutiques

</td>
</tr>
</table>

---

### SnapCoach · v1.1.0
[⬇️ Télécharger](https://scgaming887-svg.github.io/mes-extensions-chrome/downloads/SnapCoach.zip)

Un retour honnête sur tes conversations Snapchat, dans un panneau à côté du fil.

- **Niveau d'intérêt sur 100**, avec les faits qui l'expliquent : qui écrit le plus, qui pose des questions, qui relance, délais de réponse
- **Réponses possibles**, à copier d'un clic
- **Ce qu'il ne faut pas faire** : tu écris beaucoup plus qu'elle, tu relances sans attendre, tu poses toutes les questions, le sujet n'accroche pas
- **Le bon moment** : répondre maintenant, laisser respirer, ou ne rien envoyer du tout — c'est souvent le meilleur conseil
- **Ne flatte pas.** Quand c'est mal engagé, l'extension le dit. Un score gonflé ne sert à rien
- **Marche entièrement hors ligne.** Sans clé API, aucune conversation ne quitte ton ordinateur
- **Avec une clé Claude** (facultative, à créer sur console.anthropic.com) : analyse plus fine et vraies réponses rédigées, dans le ton de la conversation

- **Les clics restent dans le panneau** : Snapchat referme la conversation dès qu'on clique ailleurs, donc les événements du panneau sont arrêtés avant de l'atteindre. Et si le fil se ferme quand même, la dernière lecture reste analysable

⚠️ **Uniquement sur [web.snapchat.com](https://web.snapchat.com)** — une extension Chrome ne peut pas voir l'application de ton téléphone.
Si le panneau n'arrive pas à lire la page, tu peux coller la conversation à la main.

🔑 **La clé API est stockée en clair dans le navigateur.** Ne l'utilise pas sur un ordinateur partagé, et révoque-la depuis la console si tu la perds.

---

### KeySound · v1.1.0
[⬇️ Télécharger](https://scgaming887-svg.github.io/mes-extensions-chrome/downloads/KeySound.zip)

Le son de ton clavier, en mieux — pendant que tu tapes sur le web.

- **10 ambiances** : thock profond, marbre, velours, crémeux, mécanique clicky, bois, pluie, bulle, machine à écrire, rétro 8-bit
- **Les sons sont synthétisés**, pas enregistrés : l'extension pèse quelques Ko au lieu de plusieurs Mo, et chaque son reste réglable
- **Quatre couches par frappe** : la matière du contact, le corps grave, une **résonance qui traîne après le contact** — c'est elle qui rend le son agréable plutôt que sec — et un scintillement aigu qui donne la sensation de proximité
- **Réverbération et stéréo** : chaque frappe tombe à un endroit légèrement différent dans une petite pièce. Curseur « Espace » pour doser, de collé à l'oreille jusqu'à très enveloppant
- **Attaque réglée par ambiance** : 1,5 ms pour le clicky qui claque, 12 ms pour le velours qui effleure
- **Espace, Entrée et Retour sonnent différemment** — c'est ce qui fait la différence entre un vrai clavier et un bip répété. La machine à écrire a même son timbre de retour chariot
- **Variation de hauteur** à chaque frappe : sans elle, l'oreille entend une machine
- **Son de remontée de touche** en option, pour le réalisme
- Volume réglable, coupure par site, et bouton pour tout couper d'un clic
- **Aucune touche n'est enregistrée** : seule la catégorie (lettre, espace, entrée, retour) est lue pour choisir le son, puis oubliée. Option pour rester muet dans les champs de mot de passe

⚠️ **Uniquement dans le navigateur.** Une extension Chrome n'entend pas ce que tu tapes dans Word, Discord ou un jeu — il faudrait un logiciel Windows pour ça.

⚠️ Le son s'**ajoute** au bruit réel de ton clavier, il ne le remplace pas.

---

### FocusBlock · v1.0.0
[⬇️ Télécharger](https://scgaming887-svg.github.io/mes-extensions-chrome/downloads/FocusBlock.zip)

Bloque carrément un site, pour la durée que tu choisis.

- **Choix rapides** : YouTube, TikTok, Snapchat, Instagram, Facebook, X/Twitter, Reddit, Netflix — ou tape n'importe quelle adresse (plusieurs à la fois, séparées par une virgule)
- **Durée libre** : 15 min, 30 min, 1 h, 2 h, 4 h, jusqu'à demain 6 h, ou une valeur à toi en minutes, heures ou jours
- **Vraiment bloqué** : le site redirige vers une page d'attente avec le temps restant, pas une erreur de navigateur — et retirer un blocage avant l'heure demande une confirmation, pas un simple clic
- Fonctionne sans connexion ni serveur distant : une règle `declarativeNetRequest` locale, posée par le navigateur lui-même
- Plusieurs sites à la fois reçoivent la même durée en un seul clic
- Se débloque tout seul à l'heure prévue, même si l'ordinateur a dormi entre-temps
- Bloquer un site déjà bloqué repart de maintenant avec la nouvelle durée, au lieu de les additionner

⚠️ Bloque le **domaine entier** (tous les sous-domaines compris) : bloquer `facebook.com` bloque aussi Messenger si tu y accèdes depuis le navigateur.

---

## Installation

Va sur la **[page de téléchargement](https://scgaming887-svg.github.io/mes-extensions-chrome/)**, prends le `.zip` qui t'intéresse, puis :

1. **Décompresse-le** — clic droit → *Extraire tout*. Chrome ne lit pas les archives, il lui faut un dossier. Garde-le à un endroit fixe.
2. Ouvre **`chrome://extensions`** *(ou `edge://extensions` sur Edge)*
3. Active le **Mode développeur**, en haut à droite
4. Clique **Charger l'extension non empaquetée** et choisis le dossier extrait

> **À savoir** : Chrome affiche un bandeau « Désactiver les extensions en mode développeur » à chaque démarrage. C'est normal hors du Web Store, tu peux le fermer. Et si tu déplaces ou supprimes le dossier, l'extension cesse de fonctionner.

### Depuis le dépôt (pour développer)

```bash
git clone https://github.com/scgaming887-svg/mes-extensions-chrome.git
```

Puis charge directement les dossiers `GameOpen/`, `PageCustomer/`, `PetPage/`, `ResearchFast.Page/`, `SnapCoach/`, `KeySound/` ou `FocusBlock/`.
Après chaque modification : bouton ↻ sur `chrome://extensions`, et recharge l'onglet
pour les trois extensions qui s'injectent dans les pages.

---

## Comment ResearchFast classe les offres

Chaque annonce reçoit une note sur 100 qui croise **pertinence, prix, qualité et fiabilité**.
La pondération change selon la place de ton budget dans le marché — comparée au **prix médian**
des annonces trouvées :

| Ton budget | Poids du prix | Poids de la qualité | Mode affiché |
|---|---|---|---|
| Moins de 0,8 × le médian | **47 %** | 25 % | *Budget serré : priorité au prix* |
| Entre 0,8 × et 1,6 × | 33 % | 37 % | *Budget moyen : à parts égales* |
| Plus de 1,6 ×, ou aucun budget | 18 % | **52 %** | *Budget confortable : priorité à la qualité* |

Deux principes derrière ça :

- **Dépenser son budget n'est pas une faute.** La pénalité de prix est plafonnée, sinon le
  classement pousserait toujours vers le moins cher et le budget ne servirait à rien.
- **Un article mal noté ne prend jamais la tête.** Sous 3,5 ★, il subit un malus même en
  chasse au prix. Un rabais ne rachète pas trois étoiles.

### Les boutiques couvertes

| Boutique | Comment la recherche est lancée | Pays |
|---|---|---|
| Amazon | adresse directe `/s?k=` | .ca · .com · .fr |
| eBay | adresse directe `_nkw=` | .ca · .com · .fr |
| Best Buy | adresse directe `/fr-ca/chercher?search=` · repli : saisie dans leur champ | Canada · États-Unis |
| Newegg | adresse directe `/p/pl?d=` | Canada · États-Unis |
| Marketplace | adresse directe `/marketplace/search/` | partout |
| Autres boutiques | bouton 🔎 pour scanner la page affichée | partout |

Best Buy est un cas à part : **son chemin de recherche est traduit**. En français c'est
`/fr-ca/chercher`, pas `/fr-ca/search` — ce dernier renvoie une page 404. Le site bloquant
toute vérification automatique (403), l'adresse a dû être relevée depuis un vrai navigateur.

Même chose pour les fiches produit : `/fr-ca/produit/` en français, `/product/` en anglais.
L'extension reconnaît les deux.

Filet de sécurité : si l'extension atterrit ailleurs que sur des résultats — 404, accueil,
adresse changée — elle **tape la recherche dans leur propre champ** et laisse le site
fabriquer la bonne adresse. Et dans tous les cas elle finit par enregistrer un résultat,
même vide : une colonne du comparateur ne peut jamais rester bloquée sur « scan en cours ».

### Ce que « la note » signifie sur chaque site

| Site | La note porte sur | Détail |
|---|---|---|
| Amazon | **le produit** | étoiles et nombre d'avis de la fiche |
| eBay | **le vendeur** | son % d'avis positifs et son nombre de ventes — 90 % → 0 ★, 100 % → 5 ★ |
| Best Buy | **le produit** | étoiles et nombre d'avis de la fiche · Canada et États-Unis seulement |
| Newegg | **le produit** | étoiles (demi-étoiles comprises) et nombre d'avis · Canada et États-Unis seulement |
| Marketplace | **rien** | Facebook ne publie aucune note sur ses pages de résultats |

Chaque note est étiquetée et colorée selon sa nature, pour ne jamais mélanger « 4,7 ★ produit »
et « 99 % vendeur ». Une note inconnue est traitée comme neutre : ni favorisée, ni pénalisée.

---

## Interactions PetPage

| Geste sur l'animal | Effet |
|---|---|
| 1 clic | caresse, petit saut et cœurs qui montent |
| 2 clics | une gamelle tombe du ciel, il court la manger |
| Cliquer-glisser | on l'attrape et on le lance, il retombe avec la gravité |
| Boutons du popup | « Nourrir » et « Sauter » à distance |

Les sauts que tu provoques — clic ou bouton — lui donnent faim plus vite : environ 38 sauts
suffisent à le faire passer de repu à « petit creux ». Les sauts qu'il fait de lui-même sont gratuits.

---

## Structure du dépôt

```
GameOpen/            manifest, popup, 6 mini-jeux
PageCustomer/        manifest, popup, content script
PetPage/             manifest, popup, compagnon animé
ResearchFast.Page/   manifest, popup, lecteur de pages de vente, page de
                     comparaison, classement partagé
SnapCoach/           manifest, popup, coach de conversation
KeySound/            manifest, popup, sons de clavier
FocusBlock/          manifest, popup, service worker (blocage declarativeNetRequest),
                     page affichée à la place du site bloqué
docs/                la page de téléchargement publiée par GitHub Pages
publier.bat          met le site à jour en ligne
PRIVACY.md           politique de confidentialité
```

Les sept extensions sont en **Manifest V3**, sans aucune dépendance ni outil de build :
du HTML, du CSS et du JavaScript, lisibles tels quels.

---

## Compatibilité connue

| | Chrome | Edge |
|---|---|---|
| GameOpen | ✅ | à vérifier |
| PageCustomer | ✅ | à vérifier |
| PetPage | ✅ | ✅ |
| ResearchFast.Page | ✅ | à vérifier |
| SnapCoach | ✅ | à vérifier |
| KeySound | ✅ | à vérifier |
| FocusBlock | ✅ | à vérifier |

Edge est basé sur Chromium : ces extensions s'y chargent de la même façon.
PetPage y a été confirmée, les autres devraient suivre sans surprise.

---

## Vie privée

Aucune donnée n'est collectée, aucune connexion réseau n'est faite. Tous les réglages
restent dans le stockage local de ton navigateur (`chrome.storage.local`) et sont
supprimés avec l'extension.

ResearchFast.Page lit le contenu des pages de résultats que tu lui demandes de scanner —
c'est sa fonction même — mais rien n'en sort. Détails dans [PRIVACY.md](PRIVACY.md).

---

<div align="center">
<sub>Fait avec Claude Code · Icônes générées en vectoriel</sub>
</div>
